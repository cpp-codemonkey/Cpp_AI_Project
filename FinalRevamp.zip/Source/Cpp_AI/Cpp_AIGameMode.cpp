// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "Cpp_AIGameMode.h"
#include "Cpp_AICharacter.h"
#include "UObject/ConstructorHelpers.h"
#include "PatrolPath.h"

ACpp_AIGameMode::ACpp_AIGameMode()
{
	// set default pawn class to our Blueprinted character
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnBPClass(TEXT("/Game/ThirdPersonCPP/Blueprints/ThirdPersonCharacter"));
	if (PlayerPawnBPClass.Class != NULL)
	{
		DefaultPawnClass = PlayerPawnBPClass.Class;
	}
	static ConstructorHelpers::FClassFinder<ANPC> npc(TEXT("Blueprint'/Game/AI/NPC'"));
	if (npc.Succeeded())
	{
		FNPC_Class = npc.Class;
	}
	static ConstructorHelpers::FClassFinder<APatrolPath> Patrol(TEXT("Blueprint'/Game/AI/PatrolPath_BP'"));
	if (Patrol.Succeeded())
	{
		FPatrolPath_Class = Patrol.Class;
	}
}

void ACpp_AIGameMode::BeginPlay()
{
	Super::BeginPlay();
	if (FNPC_Class && FPatrolPath_Class)
	{
		FVector const NPC_loc{-1011.29126f, -703.557251f, 226.001602f};
		FVector const PatrolPath_loc{-605.f, -1110.f, 130.f};
		FActorSpawnParameters const params;
		if (auto const path = GetWorld()->SpawnActor<APatrolPath>(FPatrolPath_Class, PatrolPath_loc, FRotator::ZeroRotator, params))
		{
			path->AddPatrolPoint(FVector{0.f, 0.f, 0.f});			
			path->AddPatrolPoint(FVector{1550.f, -30.f, 0.f});			
			path->AddPatrolPoint(FVector{1580.f, 2290.f, 0.f});			
			path->AddPatrolPoint(FVector{90.f, 2350.f, 0.f});			
			path->AddPatrolPoint(FVector{0.f, 1150.f, 0.f});
			if (auto const NPC = GetWorld()->SpawnActor<ANPC>(FNPC_Class, NPC_loc, FRotator::ZeroRotator, params))
			{
				NPC->SetPatrolPath(path);
			}
		}
	}
}

