// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "Perception/AIPerceptionTypes.h"
#include "NPC_AIController.generated.h"

UCLASS()
class CPP_AI_API ANPC_AIController : public AAIController
{
	GENERATED_BODY()
public:	
	ANPC_AIController(FObjectInitializer const& ObjectInitializer = FObjectInitializer::Get());
	void OnPossess(APawn* const CharacterPawn) override;
private:
	UPROPERTY()
	UBlackboardComponent* BlackboardComponent;

	class UAISenseConfig_Sight* SightConfig;

	class UAISenseConfig_Hearing* HearingConfig;

	UFUNCTION()
	void OnUpdated(TArray<AActor*> const& UpdatedActors);

	void SetupPerceptionSystem();
};
