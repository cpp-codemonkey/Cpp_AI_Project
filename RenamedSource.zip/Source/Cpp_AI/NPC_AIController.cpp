// Fill out your copyright notice in the Description page of Project Settings.


#include "NPC_AIController.h"
#include "BehaviorTree/BehaviorTreeComponent.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "UObject/ConstructorHelpers.h"
#include "Cpp_AICharacter.h"
#include "Perception/AISenseConfig_Sight.h"
#include "Perception/AISenseConfig_Hearing.h"
#include "Perception/AIPerceptionStimuliSourceComponent.h"
#include "Perception/AIPerceptionComponent.h"
#include "blackboard_keys.h"
#include "ai_tags.h"
#include "GameFramework/Character.h"
#include "Runtime/Engine/Classes/Kismet/GameplayStatics.h"
#include "Runtime/Engine/Classes/Engine/Engine.h"

ANPC_AIController::ANPC_AIController(FObjectInitializer const& ObjectInitializer)
{
	static ConstructorHelpers::FObjectFinder<UBehaviorTree> Obj(TEXT("BehaviorTree'/Game/AI/NPC_BT.NPC_BT'"));
	if (Obj.Succeeded())
	{
		BTree = Obj.Object;
	}
	BehaviorTreeComponent = ObjectInitializer.CreateDefaultSubobject<UBehaviorTreeComponent>(this, TEXT("BehaviorComp"));
	Blackboard = ObjectInitializer.CreateDefaultSubobject<UBlackboardComponent>(this, TEXT("BlackboardComp"));
	SetupPerceptionSystem();
}

void ANPC_AIController::BeginPlay()
{
	Super::BeginPlay();

	RunBehaviorTree(BTree);
	BehaviorTreeComponent->StartTree(*BTree);
}

void ANPC_AIController::OnPossess(APawn* const CharacterPawn)
{
	Super::OnPossess(CharacterPawn);
	if (Blackboard)
	{
		Blackboard->InitializeBlackboard(*BTree->BlackboardAsset);
	}
	UE_LOG(LogTemp, Warning, TEXT("OnPossess"));
}

UBlackboardComponent* ANPC_AIController::GetBlackboard() const
{
	return Blackboard;
}

void ANPC_AIController::OnUpdated(TArray<AActor*> const& UpdatedActors)
{
	for (size_t x = 0; x < UpdatedActors.Num(); ++x)
	{
		FActorPerceptionBlueprintInfo Info;
		GetPerceptionComponent()->GetActorsPerception(UpdatedActors[x], Info);
		for (size_t k = 0; k < Info.LastSensedStimuli.Num(); ++k)
		{
			FAIStimulus const Stim = Info.LastSensedStimuli[k];
			if (Stim.Tag == tags::NoiseTag)
			{
				GetBlackboard()->SetValueAsBool(BBKeys::IsInvestigating, Stim.WasSuccessfullySensed());
				GetBlackboard()->SetValueAsVector(BBKeys::TargetLocation, Stim.StimulusLocation);
			}
			else if (Stim.Type.Name == "Default__AISense_Sight")
			{
				GetBlackboard()->SetValueAsBool(BBKeys::CanSeePlayer, Stim.WasSuccessfullySensed());
			}
		}
	}
}

void ANPC_AIController::SetupPerceptionSystem()
{
	// create and initialise sight configuration object
	SightConfig = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("Sight Config"));
	if (SightConfig)
	{
		SetPerceptionComponent(*CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("Perception Component")));
		SightConfig->SightRadius = 500.0f;
		SightConfig->LoseSightRadius = SightConfig->SightRadius + 25.0f;
		SightConfig->PeripheralVisionAngleDegrees = 90.0f;
		SightConfig->SetMaxAge(5.0f);
		SightConfig->AutoSuccessRangeFromLastSeenLocation = 520.0f;
		SightConfig->DetectionByAffiliation.bDetectEnemies = 
			SightConfig->DetectionByAffiliation.bDetectFriendlies = 
			SightConfig->DetectionByAffiliation.bDetectNeutrals = true;

		// add sight configuration component to perception component
		GetPerceptionComponent()->SetDominantSense(*SightConfig->GetSenseImplementation());
		GetPerceptionComponent()->ConfigureSense(*SightConfig);
	}

	// create and initialise hearing config object
	HearingConfig = CreateDefaultSubobject<UAISenseConfig_Hearing>(TEXT("Hearing config"));
	if (HearingConfig)
	{
		HearingConfig->HearingRange = 3000.0f;
		HearingConfig->DetectionByAffiliation.bDetectEnemies =
			HearingConfig->DetectionByAffiliation.bDetectFriendlies =
			HearingConfig->DetectionByAffiliation.bDetectNeutrals = true;

		// add sight configuration component to perception component
		GetPerceptionComponent()->OnPerceptionUpdated.AddDynamic(this, &ANPC_AIController::OnUpdated);
		GetPerceptionComponent()->ConfigureSense(*HearingConfig);
	}
}
