#pragma once

namespace tags
{
	TCHAR const * const NoiseTag = TEXT("Noise");
}