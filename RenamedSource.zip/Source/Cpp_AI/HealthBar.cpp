#include "HealthBar.h"


void UHealthBar::NativeConstruct()
{
}

void UHealthBar::SetHealthBarValuePercent(float const Value)
{
	HealthValue->SetPercent(Value);
}
